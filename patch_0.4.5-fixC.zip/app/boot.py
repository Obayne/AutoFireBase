import os, sys, pathlib, json

PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]

def load_updates_folder():
    # 1) env var wins
    env = os.environ.get("AUTOFIRE_UPDATES")
    if env:
        return env
    # 2) project autofire.json
    prj = PROJECT_ROOT / "autofire.json"
    if prj.exists():
        try:
            data = json.loads(prj.read_text(encoding="utf-8"))
            v = data.get("updates_folder")
            if v: return v
        except Exception:
            pass
    # 3) user autofire.json in %USERPROFILE%\AutoFire\
    user = pathlib.Path(os.path.expanduser("~")) / "AutoFire" / "autofire.json"
    if user.exists():
        try:
            data = json.loads(user.read_text(encoding="utf-8"))
            v = data.get("updates_folder")
            if v: return v
        except Exception:
            pass
    # default
    return r"C:\AutoFireUpdates"

UPDATES_FOLDER = load_updates_folder()

# Run updater (fail-safe)
try:
    from updater.auto_update import run_update
    run_update(str(PROJECT_ROOT), UPDATES_FOLDER)
except Exception as ex:
    try:
        from core.logger import get_logger
        get_logger("autofire_app").error(f"Updater failed: {ex}")
    except Exception:
        pass

# Launch the real app
try:
    from .main import main as app_main
except Exception:
    # fallback minimal window
    from PySide6 import QtWidgets
    def app_main():
        app = QtWidgets.QApplication(sys.argv)
        win = QtWidgets.QMainWindow()
        win.setWindowTitle("Auto-Fire (Launcher)")
        win.show()
        app.exec()

if __name__ == "__main__":
    app_main()