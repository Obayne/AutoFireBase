import os, sys, json, pathlib, traceback, importlib
from PySide6 import QtWidgets

PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    from core import error_hook  # sets sys.excepthook
except Exception:
    pass

def load_updates_folder():
    env = os.environ.get("AUTOFIRE_UPDATES")
    if env: return env
    prj = PROJECT_ROOT / "autofire.json"
    if prj.exists():
        try:
            data = json.loads(prj.read_text(encoding="utf-8"))
            v = data.get("updates_folder")
            if v: return v
        except Exception:
            pass
    user = pathlib.Path(os.path.expanduser("~")) / "AutoFire" / "autofire.json"
    if user.exists():
        try:
            data = json.loads(user.read_text(encoding="utf-8"))
            v = data.get("updates_folder")
            if v: return v
        except Exception:
            pass
    return r"C:\AutoFireUpdates"

def run_updater_safe():
    try:
        mod = importlib.import_module('updater.auto_update')
        mod.run_update(str(PROJECT_ROOT), load_updates_folder())
    except Exception as ex:
        try:
            from core.logger_bridge import get_app_logger
            get_app_logger().error(f"Updater failed: {ex}")
        except Exception:
            pass

def main():
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)
    run_updater_safe()

    try:
        real_main = importlib.import_module('app.main').main
        real_main()
        return
    except Exception as ex:
        # Tell the user exactly why main UI failed
        try:
            QtWidgets.QMessageBox.critical(None, "Auto-Fire Error (Main UI failed)",
                "".join(traceback.format_exception(type(ex), ex, ex.__traceback__))[:2000])
        except Exception:
            pass
        # Try fallback
        try:
            importlib.import_module('app.minwin').run_minimal()
        except Exception as ex2:
            QtWidgets.QMessageBox.critical(None, "Auto-Fire Fatal Error",
                "Both main UI and fallback failed:\n\n" + "".join(traceback.format_exception(type(ex2), ex2, ex2.__traceback__))[:2000])

if __name__ == "__main__":
    main()