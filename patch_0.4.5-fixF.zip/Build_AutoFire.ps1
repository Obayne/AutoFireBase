Param()

Write-Host "==============================================="
Write-Host "  AutoFire PowerShell Build (safe)"
Write-Host "==============================================="

# 0) Project sanity
if (!(Test-Path .\app)) {
  Write-Host "ERROR: 'app' folder not found here. Run this from your AutoFire Base folder." -ForegroundColor Red
  exit 1
}
if (!(Test-Path .\app\boot.py)) {
  Write-Host "ERROR: app\boot.py missing. Apply patch_0.4.5-fixC.zip first:" -ForegroundColor Red
  Write-Host '  python tools\apply_patch.py --project "." --patch ".\patch_0.4.5-fixC.zip"'
  exit 1
}

# 1) Python alias
$py = "py"
try { & $py -V | Out-Null } catch { $py = "python" }
try { & $py -V | Out-Null } catch {
  Write-Host "ERROR: Python not found. Install Python 3.11+ and rerun." -ForegroundColor Red
  exit 1
}

# 2) Deps
Write-Host "Installing build requirements (pip, PySide6, ezdxf, packaging, pyinstaller) ..."
& $py -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { Write-Host "ERROR: pip upgrade failed." -ForegroundColor Red; exit 1 }
& $py -m pip install PySide6 ezdxf packaging pyinstaller
if ($LASTEXITCODE -ne 0) { Write-Host "ERROR: package install failed." -ForegroundColor Red; exit 1 }

# 3) Build
Write-Host "Building AutoFire.exe ..."
& $py -m PyInstaller --noconfirm --clean --noconsole --name AutoFire --add-data "VERSION.txt;." app\boot.py
if ($LASTEXITCODE -ne 0) { Write-Host "ERROR: PyInstaller failed." -ForegroundColor Red; exit 1 }

if (!(Test-Path .\dist\AutoFire\AutoFire.exe)) {
  Write-Host "ERROR: Build finished but EXE not found." -ForegroundColor Red
  exit 1
}

Write-Host "SUCCESS: dist\AutoFire\AutoFire.exe"
Start-Process ".\dist\AutoFire"