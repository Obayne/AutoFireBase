def load_catalog():
    return [
        {"name": "Smoke Detector", "symbol": "SMK", "manufacturer": "Generic", "part_number": "SMK-100", "type": "Detector", "attributes": {}},
        {"name": "Heat Detector",  "symbol": "HEAT","manufacturer": "Generic", "part_number": "HEAT-100", "type": "Detector", "attributes": {}},
        {"name": "Horn/Strobe",    "symbol": "H/S", "manufacturer": "Generic", "part_number": "HS-100", "type": "Notification", "attributes": {"strobe": {"candela_options": [15, 30, 75, 110]}, "horn": {"db_ref": 85}}},
        {"name": "Speaker",        "symbol": "SPK", "manufacturer": "Generic", "part_number": "SPK-25VRMS", "type": "Notification", "attributes": {"speaker": {"wattage_options": [0.25, 0.5, 1.0, 2.0], "db_at_10ft": 87}}},
        {"name": "Pull Station",   "symbol": "PULL","manufacturer": "Generic", "part_number": "PULL-100", "type": "Pull", "attributes": {}},
        {"name": "FACP Panel",     "symbol": "FACP","manufacturer": "Generic", "part_number": "FACP-100", "type": "Panel", "attributes": {}},
    ]

def list_manufacturers(devs):
    vals = sorted({d.get("manufacturer","") for d in devs if d.get("manufacturer")})
    return ["(Any)"] + vals

def list_types(devs):
    vals = sorted({d.get("type","") for d in devs if d.get("type")})
    return ["(Any)"] + vals