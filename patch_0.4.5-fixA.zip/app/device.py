from PySide6 import QtGui, QtWidgets
from PySide6.QtCore import Qt, QRectF

DEVICE_RADIUS = 10

def dev_color(name: str) -> QtGui.QColor:
    n = (name or "").lower()
    if "smoke" in n or "heat" in n or "detector" in n: return QtGui.QColor(66,133,244)
    if "horn" in n or "strobe" in n: return QtGui.QColor(219,68,55)
    if "pull" in n: return QtGui.QColor(15,157,88)
    if "facp" in n or "panel" in n: return QtGui.QColor(244,180,0)
    return QtGui.QColor(255,215,0)

class DeviceItem(QtWidgets.QGraphicsEllipseItem):
    def __init__(self, x, y, symbol, name, manufacturer="Generic", part_number=""):
        super().__init__()
        self.name = name
        self.symbol = symbol
        self.manufacturer = manufacturer
        self.part_number = part_number
        r = DEVICE_RADIUS
        self.setRect(QRectF(-r, -r, 2*r, 2*r))
        self.setPos(x, y)
        self.setBrush(QtGui.QBrush(dev_color(name)))
        self.setPen(QtGui.QPen(Qt.black, 1))
        self.setZValue(100)
        self.setFlags(QtWidgets.QGraphicsItem.ItemIsSelectable | QtWidgets.QGraphicsItem.ItemIsMovable)
        self.label = QtWidgets.QGraphicsTextItem(self.symbol, self)
        f = self.label.font(); f.setPointSize(12); f.setBold(True); self.label.setFont(f)
        self.label.setDefaultTextColor(Qt.black)
        self.label.setPos(-DEVICE_RADIUS, -DEVICE_RADIUS-18); self.label.setZValue(101)

    def to_json(self):
        c = self.scenePos()
        return {
            "name": self.name, "symbol": self.symbol,
            "manufacturer": self.manufacturer, "part_number": self.part_number,
            "x": float(c.x()), "y": float(c.y())
        }