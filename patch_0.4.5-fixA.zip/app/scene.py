from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import QPointF
from PySide6.QtGui import QPainter, QPen

DEFAULT_GRID_SIZE = 20

class GridScene(QtWidgets.QGraphicsScene):
    def __init__(self, grid_size=DEFAULT_GRID_SIZE, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.snap_enabled = True
        self.show_grid = True
        self.grid_size = grid_size

    def drawBackground(self, painter: QPainter, rect: QtCore.QRectF) -> None:
        if not self.show_grid:
            return
        painter.save()
        pen = QPen(QtCore.Qt.lightGray)
        pen.setCosmetic(True)
        pen.setWidth(0)
        painter.setPen(pen)
        g = max(2, int(self.grid_size))
        left = int(rect.left()) - (int(rect.left()) % g)
        top  = int(rect.top())  - (int(rect.top())  % g)
        # vertical lines
        x = left
        while x <= rect.right():
            painter.drawLine(x, rect.top(), x, rect.bottom())
            x += g
        # horizontal lines
        y = top
        while y <= rect.bottom():
            painter.drawLine(rect.left(), y, rect.right(), y)
            y += g
        painter.restore()

    def snap(self, p: QPointF) -> QPointF:
        if not self.snap_enabled:
            return p
        g = max(2, int(self.grid_size))
        return QPointF(round(p.x()/g)*g, round(p.y()/g)*g)