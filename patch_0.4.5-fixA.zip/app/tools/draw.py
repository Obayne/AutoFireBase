from enum import IntEnum
from PySide6 import QtCore, QtWidgets, QtGui
from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QPen, QBrush, QPainterPath
from PySide6.QtWidgets import QGraphicsPathItem, QGraphicsRectItem, QGraphicsEllipseItem

SKETCH_Z = 30

class DrawMode(IntEnum):
    NONE = 0
    LINE = 1
    RECT = 2
    CIRCLE = 3
    POLYLINE = 4

class DrawController:
    def __init__(self, win, layer):
        self.win = win
        self.layer = layer
        self.mode = DrawMode.NONE
        self._pen = QPen(Qt.black, 1)
        self._brush = QBrush(Qt.transparent)
        self._temp_item = None
        self._p0 = None
        self.poly_points = []

    def set_mode(self, mode):
        if self.mode == DrawMode.POLYLINE and self.poly_points:
            # finalize an in-progress polyline
            self.finish()
        self.mode = mode
        self.win.statusBar().showMessage(f"Draw mode: {mode.name}" if mode else "Draw mode: NONE")

    def _cleanup_temp(self):
        if self._temp_item and self._temp_item.scene():
            self._temp_item.scene().removeItem(self._temp_item)
        self._temp_item = None

    def on_mouse_move(self, sp: QPointF, shift_ortho: bool=False):
        if self.mode == DrawMode.NONE:
            return
        if self.mode in (DrawMode.LINE, DrawMode.RECT, DrawMode.CIRCLE):
            if self._p0 is None:
                return
        if self.mode == DrawMode.LINE:
            p0 = self._p0
            p1 = sp
            if shift_ortho:
                # lock to horizontal or vertical
                dx = abs(p1.x() - p0.x()); dy = abs(p1.y() - p0.y())
                if dx > dy: p1.setY(p0.y())
                else: p1.setX(p0.x())
            path = QPainterPath(p0); path.lineTo(p1)
            if self._temp_item is None:
                self._temp_item = QGraphicsPathItem(path); self._temp_item.setZValue(SKETCH_Z); self._temp_item.setPen(self._pen); self._temp_item.setParentItem(self.layer)
            else:
                self._temp_item.setPath(path)

        elif self.mode == DrawMode.RECT:
            p0 = self._p0; p1 = sp
            rect = QtCore.QRectF(p0, p1).normalized()
            if self._temp_item is None:
                self._temp_item = QGraphicsRectItem(rect); self._temp_item.setZValue(SKETCH_Z); self._temp_item.setPen(self._pen); self._temp_item.setBrush(self._brush); self._temp_item.setParentItem(self.layer)
            else:
                self._temp_item.setRect(rect)

        elif self.mode == DrawMode.CIRCLE:
            p0 = self._p0; p1 = sp
            r = ((p1.x()-p0.x())**2 + (p1.y()-p0.y())**2) ** 0.5
            rect = QtCore.QRectF(p0.x()-r, p0.y()-r, 2*r, 2*r)
            if self._temp_item is None:
                self._temp_item = QGraphicsEllipseItem(rect); self._temp_item.setZValue(SKETCH_Z); self._temp_item.setPen(self._pen); self._temp_item.setBrush(self._brush); self._temp_item.setParentItem(self.layer)
            else:
                self._temp_item.setRect(rect)

        elif self.mode == DrawMode.POLYLINE:
            # preview path through poly_points + current sp
            if not self.poly_points:
                return
            path = QPainterPath(self.poly_points[0])
            for p in self.poly_points[1:]:
                path.lineTo(p)
            path.lineTo(sp)
            if self._temp_item is None:
                self._temp_item = QGraphicsPathItem(path); self._temp_item.setZValue(SKETCH_Z); self._temp_item.setPen(self._pen); self._temp_item.setParentItem(self.layer)
            else:
                self._temp_item.setPath(path)

    def on_click(self, sp: QPointF, shift_ortho: bool=False) -> bool:
        if self.mode == DrawMode.NONE:
            return False
        if self.mode in (DrawMode.LINE, DrawMode.RECT, DrawMode.CIRCLE):
            if self._p0 is None:
                self._p0 = sp
                return False
            # second click commits
            self.on_mouse_move(sp, shift_ortho=shift_ortho)
            self._temp_item = None
            self._p0 = None
            return True
        elif self.mode == DrawMode.POLYLINE:
            if not self.poly_points:
                self.poly_points = [sp]
                return False
            # allow ortho between last point and sp
            p0 = self.poly_points[-1]
            if shift_ortho:
                dx = abs(sp.x() - p0.x()); dy = abs(sp.y() - p0.y())
                if dx > dy: sp.setY(p0.y())
                else: sp.setX(p0.x())
            self.poly_points.append(sp)
            # do not finalize yet; middle-click or ESC to finish, or double-click handled by finish()
            return False
        return False

    def finish(self):
        if self.mode == DrawMode.POLYLINE and len(self.poly_points) >= 2:
            path = QPainterPath(self.poly_points[0])
            for p in self.poly_points[1:]:
                path.lineTo(p)
            item = QGraphicsPathItem(path)
            item.setZValue(SKETCH_Z); item.setPen(self._pen)
            item.setParentItem(self.layer)
        self._cleanup_temp()
        self._p0 = None
        self.poly_points = []
        self.mode = DrawMode.NONE