# 0.4.5-fixA
- Restore working core features (grid, snap, palette filters, device placement, draw tools, DXF underlay, save/open)
- Add basic logging and minimal structure
