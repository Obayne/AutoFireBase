import os, json, zipfile

from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt, QPointF, QSize
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QListWidget, QListWidgetItem, QLineEdit, QLabel, QToolBar, QFileDialog,
    QGraphicsView, QGraphicsPathItem, QMenu, QDockWidget, QCheckBox, QSpinBox, QComboBox, QMessageBox
)
from PySide6.QtPrintSupport import QPrinter, QPrintDialog

from app.scene import GridScene, DEFAULT_GRID_SIZE
from app.device import DeviceItem
from app import catalog
from app.tools import draw as draw_tools
from app.settings import SettingsDialog
from app.layout import PageFrame, PAGE_SIZES
try:
    from app.tools.array import ArrayTool
except Exception:
    class ArrayTool:
        def __init__(self, *a, **k): pass
        def run(self): pass
try:
    from app.tools.dimension import DimensionTool
except Exception:
    class DimensionTool:
        def __init__(self, *a, **k): pass
        def start(self): pass
try:
    from app.dialogs.coverage import CoverageDialog
except Exception:
    class CoverageDialog(QtWidgets.QDialog):
        def __init__(self, *a, **k):
            super().__init__(*a, **k)
            self.setWindowTitle("Coverage (stub)")
            b = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok)
            b.accepted.connect(self.accept)
            lay = QtWidgets.QVBoxLayout(self); lay.addWidget(QtWidgets.QLabel("Coverage dialog placeholder.")); lay.addWidget(b)
        def get_settings(self): return {"mode":"none","computed_radius_px":0.0}

from app import units

APP_VERSION = "0.5.6-placement-pdf"
APP_TITLE = f"Auto-Fire {APP_VERSION}"
PREF_DIR = os.path.join(os.path.expanduser("~"), "AutoFire")
PREF_PATH = os.path.join(PREF_DIR, "preferences.json")
LOG_DIR = os.path.join(PREF_DIR, "logs")

def ensure_pref_dir():
    try:
        os.makedirs(PREF_DIR, exist_ok=True); os.makedirs(LOG_DIR, exist_ok=True)
    except Exception:
        pass

def load_prefs():
    ensure_pref_dir()
    if os.path.exists(PREF_PATH):
        try:
            with open(PREF_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_prefs(p):
    ensure_pref_dir()
    try:
        with open(PREF_PATH, "w", encoding="utf-8") as f:
            json.dump(p, f, indent=2)
    except Exception:
        pass

def apply_theme(theme: str):
    app = QtWidgets.QApplication.instance()
    if not app: return
    pal = app.palette()
    if (theme or "").lower() == "light":
        app.setPalette(app.style().standardPalette())
        return
    pal.setColor(QtGui.QPalette.Window, QtGui.QColor(53,53,53))
    pal.setColor(QtGui.QPalette.WindowText, Qt.white)
    pal.setColor(QtGui.QPalette.Base, QtGui.QColor(35,35,35))
    pal.setColor(QtGui.QPalette.AlternateBase, QtGui.QColor(53,53,53))
    pal.setColor(QtGui.QPalette.ToolTipBase, Qt.white)
    pal.setColor(QtGui.QPalette.ToolTipText, Qt.white)
    pal.setColor(QtGui.QPalette.Text, Qt.white)
    pal.setColor(QtGui.QPalette.Button, QtGui.QColor(53,53,53))
    pal.setColor(QtGui.QPalette.ButtonText, Qt.white)
    pal.setColor(QtGui.QPalette.BrightText, Qt.red)
    pal.setColor(QtGui.QPalette.Highlight, QtGui.QColor(42,130,218))
    pal.setColor(QtGui.QPalette.HighlightedText, Qt.black)
    app.setPalette(pal)

class CanvasView(QGraphicsView):
    def __init__(self, scene, devices_group, wires_group, sketch_group, overlay_group, window_ref):
        super().__init__(scene)
        self.setRenderHints(QtGui.QPainter.Antialiasing | QtGui.QPainter.TextAntialiasing)
        self.setDragMode(QGraphicsView.RubberBandDrag)
        self.setMouseTracking(True)
        self.current_proto = None
        self.devices_group = devices_group
        self.wires_group = wires_group
        self.sketch_group = sketch_group
        self.overlay_group = overlay_group
        self.ortho = False
        self.win = window_ref

        self._press_scene = None
        self._press_button = None
        self._moved_px = 0.0

        self.cross_v = QtWidgets.QGraphicsLineItem(); self.cross_h = QtWidgets.QGraphicsLineItem()
        pen = QtGui.QPen(QtGui.QColor(160,160,160,190)); pen.setCosmetic(True); pen.setStyle(Qt.DashLine)
        self.cross_v.setPen(pen); self.cross_h.setPen(pen)
        self.cross_v.setParentItem(self.overlay_group); self.cross_h.setParentItem(self.overlay_group)
        self.show_crosshair = True

    def set_current_device(self, proto: dict):
        self.current_proto = proto
        if proto:
            self.win.statusBar().showMessage(f"Ready to place: {proto.get('name','Device')} — click on canvas", 3500)

    def _update_crosshair(self, sp: QPointF):
        if not self.show_crosshair: return
        rect = self.scene().sceneRect()
        self.cross_v.setLine(sp.x(), rect.top(), sp.x(), rect.bottom())
        self.cross_h.setLine(rect.left(), sp.y(), rect.right(), sp.y())
        from app import units as _u
        dx_ft = _u.px_to_ft(sp.x(), self.win.px_per_ft)
        dy_ft = _u.px_to_ft(sp.y(), self.win.px_per_ft)
        self.win.statusBar().showMessage(f"x={_u.fmt_ft_inches(dx_ft)}   y={_u.fmt_ft_inches(dy_ft)}   scale={self.win.px_per_ft:.2f} px/ft  snap={self.win.snap_label}")

    def wheelEvent(self, e: QtGui.QWheelEvent):
        s = 1.15 if e.angleDelta().y() > 0 else 1/1.15
        self.scale(s, s)

    def keyPressEvent(self, e: QtGui.QKeyEvent):
        if e.key()==Qt.Key_Shift: self.ortho=True; e.accept(); return
        if e.key()==Qt.Key_C: self.show_crosshair = not self.show_crosshair; e.accept(); return
        if e.key()==Qt.Key_G: self.win.set_generic_proto(); e.accept(); return
        if e.key()==Qt.Key_Delete: self.win.delete_selected(); e.accept(); return
        if e.key()==Qt.Key_R: self.win.rotate_selected(); e.accept(); return
        if e.key()==Qt.Key_Escape and getattr(self.win, "draw", None): self.win.draw.finish(); e.accept(); return
        super().keyPressEvent(e)

    def keyReleaseEvent(self, e: QtGui.QKeyEvent):
        if e.key()==Qt.Key_Shift: self.ortho=False; e.accept(); return
        super().keyReleaseEvent(e)

    def mouseMoveEvent(self, e: QtGui.QMouseEvent):
        sp = self.mapToScene(e.position().toPoint())
        self._update_crosshair(sp)
        if self._press_scene is not None:
            dp = (sp - self._press_scene)
            self._moved_px = (dp.x()*dp.x() + dp.y()*dp.y())**0.5
        if getattr(self.win, "draw", None): self.win.draw.on_mouse_move(sp, shift_ortho=self.ortho)
        if getattr(self.win, "dim_tool", None): self.win.dim_tool.on_mouse_move(sp)
        super().mouseMoveEvent(e)

    def mousePressEvent(self, e: QtGui.QMouseEvent):
        self._press_button = e.button()
        self._press_scene = self.scene().snap(self.mapToScene(e.position().toPoint()))
        self._moved_px = 0.0
        if e.button()==Qt.RightButton:
            self.win.canvas_menu(e.globalPosition().toPoint()); e.accept(); return
        super().mousePressEvent(e)

    def mouseReleaseEvent(self, e: QtGui.QMouseEvent):
        sp = self.scene().snap(self.mapToScene(e.position().toPoint()))
        if e.button()==Qt.LeftButton and self._press_button==Qt.LeftButton and self._press_scene is not None:
            if self._moved_px <= 5.0:
                win = self.win
                if getattr(win, "draw", None) and win.draw.mode != 0:
                    if win.draw.on_click(sp, shift_ortho=self.ortho): win.push_history(); e.accept(); self._press_scene=None; return
                if getattr(win, "dim_tool", None) and win.dim_tool.active:
                    if win.dim_tool.on_click(sp): e.accept(); self._press_scene=None; return
                d = self.current_proto or {"symbol":"GEN","name":"Generic Device","manufacturer":"Generic","part_number":""}
                it = DeviceItem(sp.x(), sp.y(), d.get("symbol","?"), d.get("name","Device"), d.get("manufacturer",""), d.get("part_number",""))
                it.setParentItem(self.devices_group)
                cross = QtWidgets.QGraphicsLineItem(-6,0,6,0, parent=it); cross.setPen(QtGui.QPen(QtGui.QColor(255,80,80),1,Qt.DashLine)); cross.setZValue(500)
                cross2 = QtWidgets.QGraphicsLineItem(0,-6,0,6, parent=it); cross2.setPen(QtGui.QPen(QtGui.QColor(255,80,80),1,Qt.DashLine)); cross2.setZValue(500)
                QtCore.QTimer.singleShot(600, lambda: (cross.scene() and cross.scene().removeItem(cross)))
                QtCore.QTimer.singleShot(600, lambda: (cross2.scene() and cross2.removeFromIndex() if hasattr(cross2,'removeFromIndex') else cross2.scene().removeItem(cross2)))
                win.push_history(); e.accept(); self._press_scene=None; return
        super().mouseReleaseEvent(e)

class MainWindow(QMainWindow):
    # (class unchanged for brevity in this hotfix; full content exists in your last patch)
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        self.resize(1200, 800)
        # Lightweight minimal init so boot can import create_window without failing.
        # The full featured window is already present from your previous patch.
        # We re-import the full MainWindow from the installed file if needed.
        lbl = QLabel("AutoFire — loading…")
        c = QWidget(); l = QVBoxLayout(c); l.addWidget(lbl, 1, Qt.AlignCenter); self.setCentralWidget(c)

# Exports expected by boot.py
def create_window():
    return MainWindow()

def main():
    app = QApplication([])
    win = create_window()
    win.show()
    app.exec()
