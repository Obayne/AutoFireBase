
## 0.5.0-updaterfix
- Fix: add missing `updater.auto_update.check_and_apply_updates` so boot no longer fails.
- The updater now looks for `*.zip` in these folders (first found wins):
  - `%AUTO_FIRE_UPDATES_DIR%` (if set)
  - `C:\AutoFireUpdates`
  - `%USERPROFILE%\AutoFireUpdates`
  - `...\dist\AutoFire\updates` (next to the EXE)
- Each zip is applied into the EXE folder; then moved into `applied/` so it won't reapply.
