Write-Host "==============================================="
Write-Host " AutoFire - Build (ASCII safe)"
Write-Host "==============================================="

# Warn for OneDrive (can lock files)
$inOneDrive = $PWD.Path -like "*OneDrive*"
if ($inOneDrive) {
  Write-Warning "You're building inside OneDrive. Sync can lock files and break the build."
  Write-Warning "If you hit 'Access is denied', pause OneDrive or move the project to C:\Dev\AutoFireBase"
}

# Ensure deps
Write-Host "Installing build requirements (pip, PySide6, ezdxf, packaging, pyinstaller) ..."
python -m pip install -U pip | Out-Null
python -m pip install -U PySide6 ezdxf packaging pyinstaller | Out-Null

# Clean previous outputs and stop any EXE
& ".\Build_Clean.ps1"

# Paths
$distRoot = ".\dist"
$distOut = Join-Path $distRoot "AutoFire"
$workOut = ".\build\AutoFire"

# Build
Write-Host "Building AutoFire.exe ..."
& pyinstaller --noconfirm --distpath $distRoot --workpath $workOut AutoFire.spec
$code = $LASTEXITCODE

if ($code -ne 0) {
  Write-Warning "Primary build failed with exit code $code. Retrying with a fresh dist folder ..."
  $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
  $distAlt = Join-Path $distRoot ("AutoFire_" + $stamp)
  & pyinstaller --noconfirm --distpath $distAlt --workpath $workOut AutoFire.spec
  $code = $LASTEXITCODE
  if ($code -ne 0) {
    Write-Error "PyInstaller failed again (exit $code). See the console above."
    exit $code
  } else {
    $exe = Join-Path $distAlt "AutoFire\AutoFire.exe"
    Write-Host "Build complete (alt). EXE:"
    Write-Host $exe
    exit 0
  }
} else {
  $exe = Join-Path $distOut "AutoFire.exe"
  Write-Host "Build complete. EXE:"
  Write-Host $exe
  exit 0
}
