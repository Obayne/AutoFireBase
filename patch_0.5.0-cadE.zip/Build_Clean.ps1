Write-Host "==============================================="
Write-Host " AutoFire - Clean build folders and processes"
Write-Host "==============================================="

# Stop running EXE if present
Write-Host "Stopping any running AutoFire.exe ..."
try { Get-Process -Name AutoFire -ErrorAction Stop | Stop-Process -Force } catch {}

Start-Sleep -Milliseconds 500

function SafeRemove {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (Test-Path -LiteralPath $Path) {
        try {
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            Write-Host "Removed $Path"
        } catch {
            Write-Warning ("Could not remove {0}: {1}" -f $Path, $_.Exception.Message)
        }
    }
}

SafeRemove ".\dist\AutoFire"
SafeRemove ".\build\AutoFire"

Write-Host "Clean step done."
