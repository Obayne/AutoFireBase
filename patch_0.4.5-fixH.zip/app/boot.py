import os, sys, json, pathlib, traceback
from PySide6 import QtWidgets

# --- Ensure we can import 'app', 'core', 'updater' when frozen or run as script ---
PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
PKG_ROOT = PROJECT_ROOT / "app"
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Try to install global error hook (safe if missing)
try:
    from core import error_hook  # noqa: F401 (sets sys.excepthook)
except Exception:
    pass

def load_updates_folder():
    env = os.environ.get("AUTOFIRE_UPDATES")
    if env: return env
    prj = PROJECT_ROOT / "autofire.json"
    if prj.exists():
        try:
            data = json.loads(prj.read_text(encoding="utf-8"))
            v = data.get("updates_folder")
            if v: return v
        except Exception: pass
    user = pathlib.Path(os.path.expanduser("~")) / "AutoFire" / "autofire.json"
    if user.exists():
        try:
            data = json.loads(user.read_text(encoding="utf-8"))
            v = data.get("updates_folder")
            if v: return v
        except Exception: pass
    return r"C:\AutoFireUpdates"

def run_updater_safe():
    try:
        from updater.auto_update import run_update
        run_update(str(PROJECT_ROOT), load_updates_folder())
    except Exception as ex:
        try:
            from core.logger_bridge import get_app_logger
            get_app_logger().error(f"Updater failed: {ex}")
        except Exception:
            pass

def main():
    # Start Qt early so message boxes can show
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)

    run_updater_safe()

    # Import using absolute package names so it works when frozen
    try:
        # Ensure 'app' package is importable
        if 'app' not in sys.modules:
            import importlib.util
            spec = importlib.util.spec_from_file_location('app', PKG_ROOT / '__init__.py') if (PKG_ROOT / '__init__.py').exists() else None
            # __init__.py may not exist; app is still a package-like directory — but Python requires a module.
            # In that case, just rely on sys.path pointing at PROJECT_ROOT and import by name.
        from app.main import main as real_main
        real_main()
        return
    except Exception as ex:
        # Log and fall back to a minimal window so the user always sees something
        try:
            from core.logger_bridge import get_app_logger
            get_app_logger().error("Failed to start main UI: " + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        except Exception:
            pass
        try:
            from app.minwin import run_minimal
            run_minimal()
        except Exception as ex2:
            # Last resort: show a message box with the error
            QtWidgets.QMessageBox.critical(None, "Auto-Fire Fatal Error",
                "Both main UI and fallback failed:\n\n" + "".join(traceback.format_exception(type(ex2), ex2, ex2.__traceback__))[:2000])

if __name__ == "__main__":
    main()