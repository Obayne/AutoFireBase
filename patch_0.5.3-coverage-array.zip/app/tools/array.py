from PySide6 import QtWidgets
from app import units
from app.device import DeviceItem

class _ArrayDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Place Array")
        form = QtWidgets.QFormLayout(self)

        self.rows = QtWidgets.QSpinBox(); self.rows.setRange(1, 300); self.rows.setValue(2)
        self.cols = QtWidgets.QSpinBox(); self.cols.setRange(1, 300); self.cols.setValue(3)
        form.addRow("Rows:", self.rows)
        form.addRow("Columns:", self.cols)

        self.sp_ft = QtWidgets.QSpinBox(); self.sp_ft.setRange(0, 1000); self.sp_ft.setValue(10)
        self.sp_in = QtWidgets.QSpinBox(); self.sp_in.setRange(0, 11); self.sp_in.setValue(0)
        row = QtWidgets.QHBoxLayout(); row.addWidget(self.sp_ft); row.addWidget(QtWidgets.QLabel("ft")); row.addSpacing(12); row.addWidget(self.sp_in); row.addWidget(QtWidgets.QLabel("in"))
        wrap = QtWidgets.QWidget(); wrap.setLayout(row)
        form.addRow("Spacing:", wrap)

        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        form.addRow(btns)

    def get(self):
        spacing_ft = self.sp_ft.value() + self.sp_in.value()/12.0
        return self.rows.value(), self.cols.value(), spacing_ft

class ArrayTool:
    def __init__(self, window, layer_devices):
        self.win = window
        self.layer = layer_devices

    def run(self):
        sel = [it for it in self.win.scene.selectedItems() if isinstance(it, DeviceItem)]
        if not sel:
            QtWidgets.QMessageBox.information(self.win, "Place Array", "Select a placed device to use as the anchor, then run Place Array again.")
            return
        anchor = sel[0]
        dlg = _ArrayDialog(self.win)
        if dlg.exec() != QtWidgets.QDialog.Accepted:
            return
        rows, cols, spacing_ft = dlg.get()
        spacing_px = units.ft_to_px(spacing_ft, self.win.px_per_ft)

        symbol = getattr(anchor, "symbol", "?")
        name   = getattr(anchor, "name", "Device")
        mfr    = getattr(anchor, "manufacturer", "")
        pn     = getattr(anchor, "part_number", "")

        ax, ay = anchor.pos().x(), anchor.pos().y()
        for r in range(rows):
            for c in range(cols):
                if r==0 and c==0: 
                    continue
                x = ax + c * spacing_px
                y = ay + r * spacing_px
                it = DeviceItem(x, y, symbol, name, mfr, pn)
                it.setParentItem(self.layer)
        self.win.push_history()
        self.win.statusBar().showMessage(f"Placed array {rows}x{cols} @ {spacing_ft:.2f} ft", 3500)
