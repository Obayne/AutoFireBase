import os, sys, json, pathlib, traceback, importlib

# Ensure project root is importable
PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Optional: log uncaught exceptions if the logger is available
try:
    from core import error_hook  # sets sys.excepthook
except Exception:
    pass

def load_updates_folder():
    env = os.environ.get("AUTOFIRE_UPDATES")
    if env: return env
    prj = PROJECT_ROOT / "autofire.json"
    if prj.exists():
        try:
            data = json.loads(prj.read_text(encoding="utf-8"))
            v = data.get("updates_folder")
            if v: return v
        except Exception:
            pass
    user = pathlib.Path(os.path.expanduser("~")) / "AutoFire" / "autofire.json"
    if user.exists():
        try:
            data = json.loads(user.read_text(encoding="utf-8"))
            v = data.get("updates_folder")
            if v: return v
        except Exception:
            pass
    return r"C:\AutoFireUpdates"

def run_updater_safe():
    try:
        mod = importlib.import_module('updater.auto_update')
        mod.run_update(str(PROJECT_ROOT), load_updates_folder())
    except Exception as ex:
        try:
            from core.logger_bridge import get_app_logger
            get_app_logger().error(f"Updater failed: {ex}")
        except Exception:
            pass

def main():
    # 1) Run updater without creating a QApplication
    run_updater_safe()

    # 2) Run the real UI; it will create QApplication itself
    try:
        real_main = importlib.import_module('app.main').main
        real_main()
        return
    except Exception as ex:
        # 3) On failure, create a QApplication and show an error, then fallback
        try:
            from PySide6 import QtWidgets
            app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)
            try:
                QtWidgets.QMessageBox.critical(None, "Auto-Fire Error (Main UI failed)",
                    "".join(traceback.format_exception(type(ex), ex, ex.__traceback__))[:2000])
            except Exception:
                pass
            try:
                importlib.import_module('app.minwin').run_minimal()
            except Exception as ex2:
                QtWidgets.QMessageBox.critical(None, "Auto-Fire Fatal Error",
                    "Both main UI and fallback failed:\n\n" + "".join(traceback.format_exception(type(ex2), ex2, ex2.__traceback__))[:2000])
        except Exception:
            # If Qt isn't available at all, just print
            print("Auto-Fire Error:", ex, file=sys.stderr)

if __name__ == "__main__":
    main()