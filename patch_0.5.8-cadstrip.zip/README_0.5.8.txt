
AutoFire 0.5.8 - CAD Strip & Locking

Files included:
- app/device.py  (adds Lock/Unlock support, persists 'locked' & z-value)

Notes:
- If you already have 'app/main.py' from 0.5.7 UI, the new right-click options may not appear until we update main.py next.
- Ask in chat and I'll generate a full 'app/main.py' refresh if needed.
