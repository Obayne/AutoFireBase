## 0.5.0-cadC
- Crash logs now saved to **two places**:
  1) `%USERPROFILE%\AutoFire\logs\last_crash.txt`
  2) next to the EXE: `...\AutoFire\logs\last_crash.txt`
- Error popup shows the exact paths so they’re easy to find.