import os, sys, traceback, importlib
from PySide6 import QtWidgets

# Primary log dir in user profile
USER_LOG_DIR = os.path.join(os.path.expanduser("~"), "AutoFire", "logs")
os.makedirs(USER_LOG_DIR, exist_ok=True)

# Secondary log dir: next to the EXE (or CWD in dev)
EXE_DIR = os.path.dirname(getattr(sys, "executable", sys.argv[0]))
APP_LOG_DIR = os.path.join(EXE_DIR, "logs")
try:
    os.makedirs(APP_LOG_DIR, exist_ok=True)
except Exception:
    pass

def _write_crash_to(path, text):
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        return True
    except Exception:
        return False

def _write_crash(e: BaseException):
    txt = "".join(traceback.format_exception(type(e), e, e.__traceback__))
    p1 = os.path.join(USER_LOG_DIR, "last_crash.txt")
    p2 = os.path.join(APP_LOG_DIR,  "last_crash.txt")
    ok1 = _write_crash_to(p1, txt)
    ok2 = _write_crash_to(p2, txt)
    return txt, p1, p2, ok1, ok2

def _crash_popup(title, message, p1=None, p2=None):
    extra = ""
    if p1 or p2:
        extra = "\n\nCrash logs written to:\n"
        if p1: extra += f" - {p1}\n"
        if p2: extra += f" - {p2}\n"
    try:
        QtWidgets.QMessageBox.critical(None, title, message + extra)
    except Exception:
        pass

def run_updater_safe():
    try:
        from updater.auto_update import check_and_apply_updates
        check_and_apply_updates()
    except Exception:
        # updater errors should not block app, but write them too
        e = sys.exc_info()[1]
        txt, p1, p2, _, _ = _write_crash(e)
        _crash_popup("Auto-Fire Updater Error (non-blocking)", txt, p1, p2)

def main():
    try:
        run_updater_safe()
        real_main = importlib.import_module('app.main').main
        return real_main()
    except Exception as e:
        txt, p1, p2, _, _ = _write_crash(e)
        _crash_popup("Auto-Fire Error (Main UI failed)", txt, p1, p2)
        try:
            run_minimal()
        except Exception as e2:
            txt2, p1b, p2b, _, _ = _write_crash(e2)
            _crash_popup("Auto-Fire Fatal Error", txt2, p1b, p2b)

def run_minimal():
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w = QtWidgets.QWidget()
    w.setWindowTitle("Auto-Fire — Minimal Window (Fallback)")
    lab = QtWidgets.QLabel("Fallback window loaded. If you see this, main UI didn't start.")
    lay = QtWidgets.QVBoxLayout(w); lay.addWidget(lab)
    w.resize(900, 600); w.show()
    app.exec()

if __name__ == "__main__":
    main()