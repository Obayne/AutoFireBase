from PySide6 import QtCore, QtGui, QtWidgets

DEFAULT_GRID_SIZE = 24  # pixels between grid lines (visual only)

class GridScene(QtWidgets.QGraphicsScene):
    def __init__(self, grid_size: int, *args):
        super().__init__(*args)
        self.grid_size = int(grid_size) if grid_size and grid_size > 1 else DEFAULT_GRID_SIZE
        self.show_grid = True
        self.snap_enabled = True
        self.snap_step_px = 0.0  # when >0, snap to this increment instead of grid intersections

    def drawBackground(self, painter: QtGui.QPainter, rect: QtCore.QRectF):
        if not self.show_grid:
            painter.fillRect(rect, QtGui.QColor(250, 250, 250))
            return
        painter.fillRect(rect, QtGui.QColor(252, 252, 252))
        left = int(rect.left()) - (int(rect.left()) % self.grid_size)
        top  = int(rect.top())  - (int(rect.top())  % self.grid_size)
        lines = []
        for x in range(left, int(rect.right())+self.grid_size, self.grid_size):
            lines.append(QtCore.QLineF(x, rect.top(), x, rect.bottom()))
        for y in range(top, int(rect.bottom())+self.grid_size, self.grid_size):
            lines.append(QtCore.QLineF(rect.left(), y, rect.right(), y))
        pen = QtGui.QPen(QtGui.QColor(230, 230, 230)); pen.setCosmetic(True)
        painter.setPen(pen); painter.drawLines(lines)

    def snap(self, pt: QtCore.QPointF) -> QtCore.QPointF:
        if not self.snap_enabled:
            return pt
        if self.snap_step_px and self.snap_step_px > 0:
            step = float(self.snap_step_px)
            return QtCore.QPointF(round(pt.x()/step)*step, round(pt.y()/step)*step)
        gx = self.grid_size
        return QtCore.QPointF(round(pt.x()/gx)*gx, round(pt.y()/gx)*gx)
