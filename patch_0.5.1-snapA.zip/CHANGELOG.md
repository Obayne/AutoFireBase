## 0.5.1-snapA
- Snap step choices (Grid, 6", 12", 24").
- Dimension tool (D): click start/end; ft/in label.
