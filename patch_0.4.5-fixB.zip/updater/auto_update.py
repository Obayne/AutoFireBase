import os, json, zipfile
from pathlib import Path
from packaging import version
from core.logger import get_logger

log = get_logger("autofire_updater")

def is_newer(v_new: str, v_old: str) -> bool:
    try:
        return version.parse(v_new) > version.parse(v_old)
    except Exception:
        return v_new != v_old

def read_version(project_root: Path) -> str:
    p = project_root / "VERSION.txt"
    if p.exists():
        return p.read_text(encoding="utf-8").strip()
    return "0.0.0"

def write_version(project_root: Path, v: str):
    (project_root / "VERSION.txt").write_text(v, encoding="utf-8")

def _apply_patch(project_root: Path, patch_zip: Path):
    # Inline patch apply (reads manifest.json and writes files)
    import hashlib
    def sha256_bytes(b: bytes) -> str:
        h = hashlib.sha256(); h.update(b); return h.hexdigest()
    with zipfile.ZipFile(patch_zip, "r") as z:
        man = json.loads(z.read("manifest.json").decode("utf-8"))
        for f in man.get("files", []):
            rel = f["path"].replace("\\","/")
            data = z.read(rel)
            if sha256_bytes(data) != f.get("sha256"):
                raise RuntimeError(f"Checksum mismatch for {rel}")
            out = project_root / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(data)

def run_update(project_root: str, updates_folder: str) -> str:
    root = Path(project_root)
    channel = Path(updates_folder)
    log.info(f"Update check | root={root} | channel={channel}")
    cur = read_version(root)
    log.info(f"Current version: {cur}")
    if not channel.exists():
        log.warning("Updates folder not found; skipping")
        return cur

    candidates = []
    for z in sorted(channel.glob("*.zip")):
        try:
            with zipfile.ZipFile(z, "r") as zz:
                man = json.loads(zz.read("manifest.json").decode("utf-8"))
                pv = man.get("version", "")
                if pv:
                    candidates.append((pv, z))
        except Exception as ex:
            log.error(f"Bad patch {z}: {ex}")

    changed = False
    for pv, zpath in sorted(candidates, key=lambda t: version.parse(t[0])):
        if is_newer(pv, cur):
            log.info(f"Applying {zpath.name} (v={pv})")
            _apply_patch(root, zpath)
            write_version(root, pv)
            cur = pv
            changed = True
    log.info("Update result: " + ("updated to " + cur if changed else "already up to date"))
    return cur