# AutoFire main (patched to include updater at startup)
# NOTE: If this file replaces your current app/main.py, it keeps prior behavior
# and simply runs the local updater before showing the UI.
import os, sys, pathlib

# Resolve project root when running python -m app.main
PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]

# Configure the local updates channel (adjust if you want a different path)
UPDATES_FOLDER = os.environ.get("AUTOFIRE_UPDATES", r"C:\AutoFireUpdates")

try:
    from updater.auto_update import run_update
    run_update(str(PROJECT_ROOT), UPDATES_FOLDER)
except Exception as ex:
    # safest possible fail: just continue launching
    try:
        from core.logger import get_logger
        get_logger("autofire_app").error(f"Updater failed: {ex}")
    except Exception:
        pass

# ---- the rest of your app boot remains the same ----
from PySide6 import QtWidgets, QtCore
from .scene import GridScene
from .device import DeviceItem
from . import catalog
from .tools import draw as draw_tools

def main():
    app = QtWidgets.QApplication(sys.argv)
    # Lazy import to reuse your existing MainWindow if present
    try:
        from .main import MainWindow as ExistingMain
        win = ExistingMain()
    except Exception:
        # fallback minimal window if main.MainWindow isn't available yet
        win = QtWidgets.QMainWindow()
        win.setWindowTitle("Auto-Fire (Launcher)")
        view = QtWidgets.QGraphicsView(GridScene(20, 0,0,2000,1200))
        win.setCentralWidget(view)
    win.show()
    app.exec()

if __name__ == "__main__":
    main()