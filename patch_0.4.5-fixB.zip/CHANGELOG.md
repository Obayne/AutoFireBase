# 0.4.5-fixB
- Add local-first auto-updater + logger
- Add build scripts/spec
- Provide app/boot.py launcher that runs updater before UI
