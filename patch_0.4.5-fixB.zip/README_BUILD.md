See README_BUILD in the build kit for full details.
This patch integrates the updater + logger and sets VERSION.txt baseline.