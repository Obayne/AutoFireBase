
import json, os

_DEFAULT = [
    {"symbol":"SD", "name":"Smoke Detector", "manufacturer":"Generic", "part_number":"SD-100", "type":"Detector"},
    {"symbol":"HD", "name":"Heat Detector",  "manufacturer":"Generic", "part_number":"HD-100", "type":"Heat"},
    {"symbol":"H/S", "name":"Horn/Strobe",   "manufacturer":"Generic", "part_number":"HS-100", "type":"Notification"},
    {"symbol":"SPK", "name":"Speaker",       "manufacturer":"Generic", "part_number":"SPK-100", "type":"Speaker"},
]

def load_catalog():
    try_paths = [
        os.path.join(os.getcwd(), "autofire_catalog.json"),
        os.path.join(os.path.dirname(__file__), "autofire_catalog.json"),
    ]
    for p in try_paths:
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list) and data:
                    return data
            except Exception:
                pass
    return list(_DEFAULT)

def list_manufacturers(items):
    vals = sorted({d.get("manufacturer","") or "Generic" for d in items})
    return ["(Any)"] + vals

def list_types(items):
    vals = sorted({d.get("type","") or "Device" for d in items})
    return ["(Any)"] + vals
