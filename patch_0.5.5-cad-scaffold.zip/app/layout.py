
from PySide6 import QtCore, QtGui, QtWidgets

# sizes in inches (w, h)
PAGE_SIZES = {
    "Letter": (8.5, 11),
    "Tabloid": (11, 17),
    "Arch D": (24, 36),
    "Arch E1": (30, 42),
}

class PageFrame(QtWidgets.QGraphicsItemGroup):
    def __init__(self, px_per_ft: float, size_name="Letter", orientation="Portrait", margin_in=0.5):
        super().__init__()
        self.px_per_ft = px_per_ft
        self.size_name = size_name
        self.orientation = orientation
        self.margin_in = margin_in
        self.setZValue(-50)

        self.rect_item = QtWidgets.QGraphicsRectItem()
        self.rect_item.setPen(self._pen(220)); self.rect_item.setBrush(QtGui.QColor(0,0,0,0))
        self.addToGroup(self.rect_item)

        self.margin_item = QtWidgets.QGraphicsRectItem()
        self.margin_item.setPen(self._pen(140, style=QtCore.Qt.DotLine)); self.margin_item.setBrush(QtGui.QColor(0,0,0,0))
        self.addToGroup(self.margin_item)

        self.title_item = QtWidgets.QGraphicsSimpleTextItem("Title Block (stub)")
        self.title_item.setBrush(QtGui.QBrush(QtGui.QColor(220,220,220)))
        self.title_item.setFlag(QtWidgets.QGraphicsItem.ItemIgnoresTransformations, True)
        self.addToGroup(self.title_item)

        self.update_geometry()

    def _pen(self, gray, style=QtCore.Qt.SolidLine):
        pen = QtGui.QPen(QtGui.QColor(gray,gray,gray))
        pen.setCosmetic(True); pen.setStyle(style)
        return pen

    def inches_to_scene(self, inches: float) -> float:
        ft = inches / 12.0
        return ft * self.px_per_ft

    def set_params(self, px_per_ft=None, size_name=None, orientation=None, margin_in=None):
        if px_per_ft is not None: self.px_per_ft = px_per_ft
        if size_name is not None: self.size_name = size_name
        if orientation is not None: self.orientation = orientation
        if margin_in is not None: self.margin_in = margin_in
        self.update_geometry()

    def update_geometry(self):
        w_in, h_in = PAGE_SIZES.get(self.size_name, PAGE_SIZES["Letter"])
        if (self.orientation or "Portrait").lower().startswith("land"):
            w_in, h_in = h_in, w_in
        w = self.inches_to_scene(w_in); h = self.inches_to_scene(h_in)
        m = self.inches_to_scene(self.margin_in)

        rect = QtCore.QRectF(0,0,w,h)
        self.rect_item.setRect(rect)
        self.margin_item.setRect(rect.adjusted(m,m,-m,-m))
        self.title_item.setPos(rect.right()-self.inches_to_scene(3.0), rect.bottom()-self.inches_to_scene(1.0))

    def to_json(self):
        return {"size_name": self.size_name, "orientation": self.orientation, "margin_in": float(self.margin_in)}

    def from_json(self, d):
        self.set_params(size_name=d.get("size_name", self.size_name),
                        orientation=d.get("orientation", self.orientation),
                        margin_in=float(d.get("margin_in", self.margin_in)))
        return self
