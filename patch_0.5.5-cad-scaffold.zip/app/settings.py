
from PySide6 import QtCore, QtGui, QtWidgets

class SettingsDialog(QtWidgets.QDialog):
    def __init__(self, parent, prefs: dict):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.prefs_in = dict(prefs or {})
        form = QtWidgets.QFormLayout(self)

        self.chk_grid = QtWidgets.QCheckBox()
        self.chk_grid.setChecked(bool(self.prefs_in.get("show_grid", True)))
        form.addRow("Show grid", self.chk_grid)

        self.chk_snap = QtWidgets.QCheckBox()
        self.chk_snap.setChecked(bool(self.prefs_in.get("snap", True)))
        form.addRow("Snap", self.chk_snap)

        self.cmb_theme = QtWidgets.QComboBox()
        self.cmb_theme.addItems(["Dark", "Light"])
        theme = (self.prefs_in.get("theme","dark") or "dark").capitalize()
        idx = 0 if theme=="Dark" else 1
        self.cmb_theme.setCurrentIndex(idx)
        form.addRow("Theme", self.cmb_theme)

        self.spin_ppf = QtWidgets.QDoubleSpinBox()
        self.spin_ppf.setRange(1.0, 1000.0); self.spin_ppf.setDecimals(2)
        self.spin_ppf.setValue(float(self.prefs_in.get("px_per_ft", 12.0)))
        form.addRow("Pixels per foot", self.spin_ppf)

        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        form.addRow(btns)

    def values(self):
        return {
            "show_grid": self.chk_grid.isChecked(),
            "snap": self.chk_snap.isChecked(),
            "theme": "dark" if self.cmb_theme.currentIndex()==0 else "light",
            "px_per_ft": float(self.spin_ppf.value()),
        }
