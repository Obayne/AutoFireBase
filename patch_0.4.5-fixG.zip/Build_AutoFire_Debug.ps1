Param()

Write-Host "==============================================="
Write-Host "  AutoFire PowerShell Build (DEBUG w/ console)"
Write-Host "==============================================="

if (!(Test-Path .\app)) { Write-Host "ERROR: 'app' not found" -ForegroundColor Red; exit 1 }
if (!(Test-Path .\app\boot.py)) { Write-Host "ERROR: app\boot.py missing (apply fixC)" -ForegroundColor Red; exit 1 }

$py = "py"
try { & $py -V | Out-Null } catch { $py = "python" }
try { & $py -V | Out-Null } catch { Write-Host "ERROR: Python not found" -ForegroundColor Red; exit 1 }

Write-Host "Installing deps..."
& $py -m pip install --upgrade pip
& $py -m pip install PySide6 ezdxf packaging pyinstaller

Write-Host "Building DEBUG AutoFire (console visible)..."
& $py -m PyInstaller --noconfirm --clean --name AutoFire_Debug --add-data "VERSION.txt;." --console app\boot.py
if ($LASTEXITCODE -ne 0) { Write-Host "ERROR: build failed" -ForegroundColor Red; exit 1 }

Write-Host "Run this to see live errors in the console:" -ForegroundColor Yellow
Write-Host ".\dist\AutoFire_Debug\AutoFire_Debug.exe"