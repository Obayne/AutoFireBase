import os, sys, json, pathlib, traceback
from PySide6 import QtWidgets

# Ensure logs & error dialogs for any crash
try:
    from core import error_hook  # sets sys.excepthook
except Exception:
    pass

PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]

def load_updates_folder():
    env = os.environ.get("AUTOFIRE_UPDATES")
    if env: return env
    prj = PROJECT_ROOT / "autofire.json"
    if prj.exists():
        try:
            data = json.loads(prj.read_text(encoding="utf-8"))
            v = data.get("updates_folder")
            if v: return v
        except Exception: pass
    user = pathlib.Path(os.path.expanduser("~")) / "AutoFire" / "autofire.json"
    if user.exists():
        try:
            data = json.loads(user.read_text(encoding="utf-8"))
            v = data.get("updates_folder")
            if v: return v
        except Exception: pass
    return r"C:\AutoFireUpdates"

def run_updater_safe():
    try:
        from updater.auto_update import run_update
        run_update(str(PROJECT_ROOT), load_updates_folder())
    except Exception as ex:
        try:
            from core.logger_bridge import get_app_logger
            get_app_logger().error(f"Updater failed: {ex}")
        except Exception:
            pass

def main():
    # Start Qt early so message boxes can show
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)

    run_updater_safe()

    # Try to run the real main UI
    try:
        from .main import main as real_main
        real_main()
        return
    except Exception as ex:
        try:
            from core.logger_bridge import get_app_logger
            get_app_logger().error("Failed to start main UI: " + "".join(traceback.format_exception(type(ex), ex, ex.__traceback__)))
        except Exception:
            pass
        # Show fallback minimal window
        from .minwin import run_minimal
        run_minimal()

if __name__ == "__main__":
    main()