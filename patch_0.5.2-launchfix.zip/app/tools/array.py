class ArrayTool:
    def __init__(self, window, layer_devices):
        self.win = window
        self.layer = layer_devices
    def run(self):
        try:
            self.win.statusBar().showMessage("Array tool (placeholder) — full tool coming back soon.", 3000)
        except Exception:
            pass
