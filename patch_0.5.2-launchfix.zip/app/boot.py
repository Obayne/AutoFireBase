# Robust boot: ensure QApplication exists BEFORE any QWidget is created.
from __future__ import annotations
import sys, os, datetime, traceback

LOG_ROOT = os.path.join(os.path.expanduser("~"), "AutoFire", "logs")

def ensure_logs_dir():
    try: os.makedirs(LOG_ROOT, exist_ok=True)
    except Exception: pass

def log_exception(prefix: str) -> str:
    ensure_logs_dir()
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(LOG_ROOT, f"{prefix}_{ts}.log")
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"{prefix} at {ts}\n\n")
            traceback.print_exc(file=f)
    except Exception:
        pass
    return path

def run_updater_safe():
    try:
        from updater.auto_update import check_and_apply_updates  # type: ignore
        try: check_and_apply_updates()
        except Exception: log_exception("update_error")
    except Exception:
        pass  # updater not present or incompatible; ignore

def main():
    # 1) Create QApplication first.
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication(sys.argv)

    # 2) Try updater, but never block UI on failure.
    try: run_updater_safe()
    except Exception: pass

    # 3) Start the UI through a factory that does NOT create another QApplication.
    try:
        from app.main import create_window  # type: ignore
        win = create_window()
        win.show()
        app.exec()
    except Exception:
        # Show a visible fallback + write a log
        lp = log_exception("startup_error")
        try:
            from PySide6 import QtWidgets
            w = QtWidgets.QWidget()
            w.setWindowTitle("AutoFire – Startup Error")
            lay = QtWidgets.QVBoxLayout(w)
            lab = QtWidgets.QLabel("AutoFire failed to start.\nPlease send this log file to support so we can fix it:\n\n" + lp)
            lab.setWordWrap(True); lay.addWidget(lab)
            btn = QtWidgets.QPushButton("Close"); btn.clicked.connect(w.close); lay.addWidget(btn)
            w.resize(580, 320); w.show()
            app.exec()
        except Exception:
            # If even the fallback fails, there's not much else we can do.
            pass

if __name__ == "__main__":
    main()
