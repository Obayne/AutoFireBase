from PySide6 import QtWidgets

class CoverageDialog(QtWidgets.QDialog):
    def __init__(self, parent=None, existing=None):
        super().__init__(parent)
        self.setWindowTitle("Coverage (placeholder)")
        self._existing = existing or {"mode":"none","computed_radius_px":0.0}
        info = QtWidgets.QLabel("This is a temporary Coverage dialog stub. We'll replace it with the full version.")
        info.setWordWrap(True)
        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        lay = QtWidgets.QVBoxLayout(self); lay.addWidget(info); lay.addWidget(btns)
    def get_settings(self):
        return dict(self._existing)
